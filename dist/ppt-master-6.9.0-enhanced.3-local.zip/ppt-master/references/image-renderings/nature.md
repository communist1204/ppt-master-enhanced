# Rendering: nature

Organic earthy illustration with botanical and natural motifs. Soft curves, organic shapes, earth-toned palette by default. Used for environmental / sustainability / wellness / outdoor / food / agriculture decks.

## 1. Style paragraph (paste-ready, 95 words)

> Organic illustration style with botanical and natural motifs. Forms are softly curved and asymmetric — leaves, branches, organic curves, irregular shapes that feel grown rather than drawn. Color palette leans earthy and slightly muted — forest greens, warm earth browns, terracotta, soft cream, occasional sky blue. Outlines are minimal or absent; forms are defined by color and texture. Subtle organic textures (leaf veins, wood grain, stone speckle) appear sparingly. Composition emphasizes natural balance and breathing room — never grid-aligned. Overall feel is grounded, contemplative, sustainable — well suited to wellness, environmental, and outdoor content.

---

## 2. Line, texture, depth

| Aspect | Treatment |
|---|---|
| Line quality | Minimal — forms defined by color, occasional thin organic line as accent |
| Texture | Subtle organic textures (leaf veins, wood grain) sparingly |
| Depth | Soft layering of natural elements, atmospheric perspective |
| Material | Earth-toned illustration |
| Mood | Grounded, contemplative, sustainable |

## 3. Using the deck's HEX values

nature has a strong tendency toward earth-toned material cues, but the deck's locked color roles remain authoritative:

- Primary HEX: dominant nature color (deep green, deep earth brown)
- Secondary HEX: light atmospheric tone (cream, soft sky)
- Accent HEX: a small natural pop (a flower, a fruit, a leaf vein)

If the deck's anchors are cool or corporate, keep their semantic roles and translate the organic material/lighting into that family. If this destroys the intended natural character, choose a different rendering during planning; never invent an image-only palette or alter the deck colors during execution.

---

## 4. Fewshot prompt snippets

**Snippet A — half-page sustainability scene, text_policy: none**

> Organic illustration style with botanical motifs. A soft natural scene of a single tree on a gentle hill, with curving organic forms and earthy color palette. Tree foliage in primary deep forest green `#166534` with subtle leaf-vein texture at 12% opacity. Tree trunk in warm earth brown using a darker shade. Hill in soft secondary cream `#FEF3C7` with very gentle curve. Sky in pale soft blue suggesting morning. A small accent of warm yellow `#D4AF37` flowers at the base of the tree. No hard outlines — forms defined by color contrast and soft organic edges. Composed as a 600×800 half-page block with 12% inner padding. NO text or labels. Color values are rendering guidance only.
